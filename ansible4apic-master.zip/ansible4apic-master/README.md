# APIC v10 (10.0.5.0) installation on Openshift (outside of the Cloud Pak for Integration)

Two playbooks:

1. install-apic.yaml 

2. uninstall-apic.yaml 

## Pre-requisites

A. Openshift 4.7+ cluster up and running (the playbooks were tested with OCP on IBM@Fyre)

B. Linux VM with CLI ("oc" commands) access to the OCP cluster and Internet access

C. Clusteradmin access to OCP cluster

D. access to github.ibm.com with a Git token

## Preparation tasks

- Install Git

```
yum update -y
yum install git -y
```

- Install Ansible and additional libraries with python

```
yum install python38
pip3 install ansible
pip3 install openshift
pip3 install jmespath
```

- Clone the current git repository 

`git clone https://\<your Git token\>@github.ibm.com/jm-lafont/ansible4apic.git`

- Install Rook Ceph on your OCP cluster for block storage

```
git clone https://\<your Git token\>@github.ibm.com/Szymon-Stupkiewicz/scripts.git
./scripts/rook-ceph/install-rook-ceph.sh
```

- Add the IBM entitlement key (`cp.icr.io`image library) to the global pull secret in the openshift-config project
See the details below, from IBM Docs: 

```
    Open the OpenShift web console, click Workloads > Secrets.
    Select the project openshift-config.
    Select pull-secret from the secret list.
    Select Actions > Edit Secret > Add Credentials.
    Set Registry Server Address to cp.icr.io.
    Set Username to cp.
    Set Password to your entitlement key.
    Click Save.
```
   
*With OCP 4.7+ the update of the pull secret does not trigger a reboot of the Openshift cluster.*    

- Log to your OCP cluster from the VM 

## How to use the playbook to install APIC v10
`
ansible-playbook install-apic.yaml`

(use -e wait=0 to skip default waiting time during execution)

## How to use the playbook to uninstall APIC v10
`
ansible-playbook uninstall-apic.yaml`

